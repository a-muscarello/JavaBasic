package CoreJava.MainEntryPoint;

public class TestRunner {
    public static void main(String[] args) {
        //Test Your Code Here!
    }
}
